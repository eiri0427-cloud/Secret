exports.H=function(org,title,tag){return '<div class="hd"><div><div class="org">'+org+'</div><h2>'+title+'</h2></div>'+(tag?'<span class="tag">'+tag+'</span>':'')+'</div>';};
exports.QA=function(pairs){return pairs.map(function(p){return '<p class="q">問：'+p[0]+'</p><p class="a">答：'+p[1]+'</p>';}).join('');};
