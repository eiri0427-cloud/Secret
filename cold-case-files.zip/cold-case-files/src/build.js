const fs=require('fs');
function fnv(s){let h=0x811c9dc5;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,0x01000193)>>>0;}return h.toString(16);}
const b64=s=>Buffer.from(s,'utf8').toString('base64');
const cases=['./case1','./case2','./case3'].map(f=>require(f));
const answers={};
for(const c of cases){
 answers[c.id]={gates:[],final:{},bts:c.bts.map(b=>[b.sus,b.docs[0],b.minGate])};
 const ids=new Set(c.docs.map(d=>d.id));
 c.bts.forEach(b=>{b.docs.forEach(d=>{if(!ids.has(d))throw new Error(c.id+' bt doc '+d);});if(!c.docs.find(d=>d.lock===b.id))throw new Error('no doc for '+b.id);if(!c.suspects.find(s=>s.id===b.sus))throw new Error('sus '+b.sus);});
 if(c.chapters.length!==c.gates.length||c.chapterIntro.length!==c.gates.length)throw new Error(c.id+' chapters');
 c.gates.forEach((g,i)=>{const a=[].concat(g.a);answers[c.id].gates.push(a[0]);g.h=a.map(x=>fnv(c.id+'|g'+i+'|'+x));delete g.a;if(g.hints.length!==3)throw new Error('hints');});
 c.final.forEach(q=>{if(!q.o.find(o=>o[0]===q.a))throw new Error(c.id+q.k);answers[c.id].final[q.k]=q.a;q.h=fnv(c.id+'|'+q.k+'|'+q.a);delete q.a;});
 c.confront.rounds.forEach(r=>r.docs.forEach(d=>{if(!ids.has(d))throw new Error(c.id+' conf '+d);}));answers[c.id].conf=c.confront.rounds.map(r=>r.docs[0]);
 c.ending=b64(c.ending);
 if(c.choice)c.choice.opts=c.choice.opts.map(o=>[o[0],b64(o[1])]);
}
const json=JSON.stringify(cases).replace(/<\/script/gi,'<\\/script');
let h=fs.readFileSync(__dirname+'/template.html','utf8').replace('/*__CASES__*/[]',()=>json);
fs.writeFileSync(__dirname+'/../index.html',h);
console.log('ok',h.length,cases.map(c=>c.docs.length));
